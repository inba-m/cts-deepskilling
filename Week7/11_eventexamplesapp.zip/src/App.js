import React, { useState } from 'react';

function App() {
  const [count, setCount] = useState(0);

  const handleIncrement = () => {
    sayHello();
    setCount(count + 1);
  };

  const sayHello = () => console.log("Hello, have a nice day!");

  const sayWelcome = (msg) => alert(msg);

  const handleCurrencyConvert = () => {
    const rupee = 100;
    alert(`€${rupee / 90}`);
  };

  return (
    <div>
      <h1>Event Examples</h1>
      <button onClick={handleIncrement}>Increment</button>
      <button onClick={() => setCount(count - 1)}>Decrement</button>
      <button onClick={() => sayWelcome("Welcome")}>Say Welcome</button>
      <button onClick={() => alert("I was clicked")}>Synthetic Event</button>
      <button onClick={handleCurrencyConvert}>Convert Currency</button>
      <div>Count: {count}</div>
    </div>
  );
}

export default App;